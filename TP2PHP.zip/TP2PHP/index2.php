<!DOCTYPE html>
<html>
<head>
    <link type="text/css" rel="stylesheet" href="style.css" media="all">
</head>
    <body>
        <header>
            <img src="https://www.grafics.fr/wp-content/uploads/2015/01/php-copyright-avec-les-annees-01.png" class="img" width="72px">
            <div class="gauche">
            <ul class="dropdown-menu" role="menu"> 
                <li><a href="acceuil.php">Acceuil</a></li> 
                <li><a href="index.php">Exercice 1 : ACHAT</a></li> 
                <li><a href="index2.php">Exercice 2 : DONS</a></li> 
            </ul>
        </div>
        </header>
        
        <div class="centre">
        <h1>Exercice 2 : DONS </h1>
        <form action="index2.php" method="post">
        <select name="don">
            <label for="user">Nom:</label><br>
            <input type="text" name="nom" value="nom"><br><br> 
            <label for="user">Age:</label><br>
            <input type="number" name="age" value="age"><br><br> 
            <label for="user">Mail:</label><br>
            <input type="text" name="mail" value="mail"><br><br> 
            <label for="user">Don:</label><br>
            <input type="number" name="don" value="don"><br><br> 
            
            <input type="submit" value="Donation">
        </form>   
            <footer>
                
            </footer>
        </div>
    </body>

</html>
<?php empty($_POST['don']) ? $don = "" :$don = $_POST['don'];?>

<?php 
$ecriture = $don;
if ($don!="") 
{
$fichier= "texte.txt";
$fp=fopen($fichier, "a+"); // ouverture en lecture ( a+) 
fputs($fp,$ecriture."\n"); // écriture fichier 
fclose($fp) ; // fermeture fichier 
    
} 
?> 

