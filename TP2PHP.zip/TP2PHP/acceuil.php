<!DOCTYPE html>
<html>
<head>
    <link type="text/css" rel="stylesheet" href="style.css" media="all">
</head>
    <body>
        <header>
            <img src="https://www.grafics.fr/wp-content/uploads/2015/01/php-copyright-avec-les-annees-01.png" class="img" width="72px">
            <div class="acceuil">
            <ul class="dropdown-menu" role="menu"> 
                <li><a href="acceuil.php">Acceuil</a></li> 
                <li><a href="index.php">Exercice 1 : ACHAT</a></li> 
                <li><a href="index2.php">Exercice 2 : DONS</a></li> 
            </ul> 
        </div>
        </header>

        
    </form>
            <footer>
                
            </footer>
        </ul> 
        </div>
    </body>

</html>