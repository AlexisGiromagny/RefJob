<html>
<head>
    <link type="text/css" rel="stylesheet" href="style.css" media="all">
</head>
    <body>
        <header>
            <img src="https://www.grafics.fr/wp-content/uploads/2015/01/php-copyright-avec-les-annees-01.png" class="img" width="72px">
            <div class="gauche">
            <ul class="dropdown-menu" role="menu"> 
                <li><a href="acceuil.php">Acceuil</a></li> 
                <li><a href="index.php">Exercice 1 : ACHAT</a></li> 
                <li><a href="index2.php">Exercice 2 : DONS</a></li> 
            </ul>
        </div>
        </header>
        

        <div class="formulaire">

        <?php

        ini_set('display_errors', 'off');

                $prof = $_POST['prof'];
                $cours = $_POST['cours'];
                $nombre = $_POST['nombre'];

            if($prof == "==Demander un professeur=="){
                echo '<br />';
                echo 'Erreur : Demander un professeur !';
            }

            if($cours == "==Demander un cours=="){
                echo '<br />';
                echo 'Erreur : Demander le cours sur lequelle vous voulez travailler !';
            }

            if($nombre == ""){
                echo '<br />';
                echo 'Erreur : Demander le nombre de cours que vous voulez !';
            }


            if($prof != "==Demander un professeur==" && $cours != "==Demander un cours==" && $nombre != "")
            {
                echo '<br />';
                echo 'Bravo vous avez commander '; echo ($nombre);
                echo (' '); echo ($cours); 
                echo ' cours avec le professeur '; echo ($prof);

            }

        ?>
        </br></br></br>
        <form>
          <input type="button" value="Revenir" onclick="history.go(-1)">
        </form>


    </div>


</body>
</html>
    </form>
            <footer>
                
            </footer>
        </ul> 
        </div>
    </body>

</html>