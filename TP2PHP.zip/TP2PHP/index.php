<!DOCTYPE html>
<html>
<head>
    <link type="text/css" rel="stylesheet" href="style.css" media="all">
</head>
    <body>
        <header>
            <img src="https://www.grafics.fr/wp-content/uploads/2015/01/php-copyright-avec-les-annees-01.png" class="img" width="72px">
            <div class="gauche">
            <ul class="dropdown-menu" role="menu"> 
                <li><a href="acceuil.php">Acceuil</a></li> 
                <li><a href="index.php">Exercice 1 : ACHAT</a></li> 
                <li><a href="index2.php">Exercice 2 : DONS</a></li> 
            </ul>
        </div>
        </header>
        
        <div class="centre">
        <h1>Exercice 1 : ACHAT </h1>
            <form name="prof" action="reponse.php" method='POST'>

            <h1>Liste des professeurs:</h1>

            <select name="prof">
                <option value="==Demander un professeur==">==Demander un professeur==</option>
                <option value="Daniel GIROD">Daniel GIROD</option>
                <option value="Laurence AGOSTINELLI">Laurence AGOSTINELLI</option>
                <option value="Isabelle DONNE">Isabelle DONNE</option>
                <option value="Bernadette VOGLER">Bernadette VOGLER</option>
            </select>

            <h1>Liste des cours:</h1>

            <select name="cours">
                <option value="==Demander un cours==">==Demander un cours==</option>
                <option value="EN">Cours d'Anglais</option>
                <option value="FR">Cours en Francais</option>
                <option value="Cours e">Cours en Hardware</option>
                <option value="Cours en Software">Cours en Software</option>
                <option value="Flash">FLASH</option>
                <option value="V">Visite d'Annecy</option>
            </select>

            <h1>Nombre de séances commander:<input type="text" name="nombre" /></h1>

        <input type="submit" name="Submit">

    </form>
            <footer>
                
            </footer>
        </ul> 
        </div>
    </body>

</html>